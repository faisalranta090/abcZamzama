@extends('layouts.default')

@section('content')
    <div class="well">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				Make Here Reports To Day Activity
			</div>
		</div>
	</div>
@endsection