@extends('layouts.default')

@section('content')
    <div class="well">
		<div class="row">
			<div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
				Add and View Category Page
			</div>
		</div>
	</div>
@endsection