<section class="footer-section">
	<div class="container">
    	<div class="row">
        	<div class="text-center">
            	&copy; <?php echo date('Y')?> Innovative-net.com |<a href="http://www.innovative-net.com/" target="_blank"  > Designed by : innovative-net.com</a>
			</div>
		</div>
	</div>
</section>