@extends('layouts.default')

@section('content')
	<div class="well">
		@include('dClient.companies.companiesMenu')
	</div>
@endsection